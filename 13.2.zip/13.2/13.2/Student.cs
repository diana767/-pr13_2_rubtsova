﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13._2
{
    class Student
    {
        private string name;
        private string surname;
        private string bookname;

        public Student(string name, string surname, string recordBookNumber)
        {
            this.name = name;
            this.surname = surname;
            this.bookname = recordBookNumber;
        }
        public string getname()
        {
            return this.name;
        }
        public void setname(string name)
        {
             this.name=name;
        }
        public string getsurname()
        {
            return this.surname;
        }
        public void setsurname(string surname)
        {
            this.surname = surname;
        }
        public string getbookname()
        {
            return this.bookname;
        }
        public void setbookname(string recordBookNumber)
        {
            this.bookname = recordBookNumber;
        }

    }
}
